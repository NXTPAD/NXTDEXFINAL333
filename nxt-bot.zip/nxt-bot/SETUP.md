# NXT Bot: setup

NXT Bot is a static site plus one small Cloudflare function. There is no build step.

## 1. Put it on GitHub
1. Create a new repository on github.com called `nxt-bot`.
2. Click **Add file → Upload files**.
3. Open the unzipped `nxt-bot` folder, select **everything inside it**, and drag it in. Don't drag the folder itself.
4. Commit.

Worked when: `index.html`, `app.js`, `config.js` and the `functions` folder are at the top level of the repo.

## 2. Connect Cloudflare Pages
1. dash.cloudflare.com → **Workers & Pages** → **Create** → **Pages** → **Connect to Git** → pick `nxt-bot`.
2. Framework preset: **None**. Build command: **empty**. Output directory: **/** (or leave empty).
3. Save and deploy. Add a custom domain later if you want one (for example `bot.yourdomain.com`).

Worked when: the site opens and the Scanner tab fills with new Solana coins within a minute.

## 3. Edit config.js (on GitHub, pencil icon)
| Setting | What to put |
|---|---|
| `SOLANA_RPC` | Your Helius mainnet URL (`https://mainnet.helius-rpc.com/?api-key=…`). The same key as NXT DEX works. In Helius, add the bot's domain to the key's allowed domains. **Needed**: the free public RPC blocks most browser traffic. |
| `JUPITER_API` / `JUPITER_KEY` | Optional. With a key from portal.jup.ag, set `JUPITER_API: "https://api.jup.ag"` and paste the key. |
| `TREASURY_SOL` | Your Solana wallet for bot fees. If it's empty, no fee is charged. |
| `FEE_STANDARD_BPS` / `FEE_HOLDER_BPS` | 100 = 1%, 50 = 0.5%. |
| `NXT_TOKEN.address` | Paste the NXT contract address the second it launches. Holders then get the lower fee. |
| `LAUNCH_AT` | When live trading unlocks. Already set to Oct 3, 2026, 00:00 Central. |

Keep every quote mark and comma. A typo blanks the site. If that happens, compare config.js with its previous version in GitHub's History.

## 4. Test before Oct 3
- **Practice mode** works now for everyone. Click **Start practice bot** and leave the tab open for 10–20 minutes. You should see buys, skipped rugs and take-profit/stop-loss sells in Activity.
- **Live mode early**: add `#preview` to the end of the address. Switch to Live → **Create** a bot wallet → **Export key** and save it → **Deposit** 0.1 SOL from Phantom → buy one coin by hand from the Scanner with a tiny buy size (0.01 SOL) → sell it from the Dashboard. Check the transactions on Solscan and that the fee reached your treasury.

## Main controls (Dashboard)
- **Buy size**, **Take-profit**, **Sell at take-profit** (how much of the coin to sell, 1–100%) and **Stop-loss** sit on the Auto-trader card. Type a number or tap a preset; it saves right away and applies to the next check.
- **Which new coins to buy**: *Any new coin* (buys every new coin it can sell back), *Balanced*, or *Strict*. Fine-tune everything else on the Strategy tab.
- Copy trading is optional, at the bottom of the Strategy tab. The bot trades new coins without it.

## How it works (what to tell users)
- **Non-custodial.** Each user's bot wallet key is created in their own browser and never sent anywhere. Users can export it to Phantom at any time.
- **Runs while the page is open.** The bot scans, buys and sells from the open tab. Phones and background tabs slow it down, so a computer with the tab kept open works best.
- **Clearing browser data deletes the bot key.** Users must back it up with Export key.
- **Data sources:** GeckoTerminal (new pools), RugCheck through `/api/rug` plus on-chain mint and freeze checks, and Jupiter (prices, sell-route test and swaps).

## Not built yet
- Robinhood Chain trading (shown as "Coming soon"). It can be added once its mainnet details are public.
- 24/7 trading with the tab closed. That needs the bot key on a server, which is no longer non-custodial. If you want it later as an opt-in, it's a separate build (Cloudflare Worker + Cron + encrypted keys).
