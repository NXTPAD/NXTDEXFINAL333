/* NXT Bot — runs entirely in the browser. The bot wallet key never leaves this device. */
(function () {
  "use strict";
  const C = window.NXT_BOT_CONFIG || {};
  const W = window.solanaWeb3;
  const SOL = "So11111111111111111111111111111111111111112";
  const USDC = "EPjFWJd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v";
  const USDT = "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB";
  const STABLE = new Set([SOL, USDC, USDT]);
  const LAMPORTS = 1e9;
  const CURVE_DEX = /pump|moonshot|launchlab|letsbonk|bonk|dbc|believe|boop/i; // bonding-curve launchpads: no pullable LP

  const $ = (s) => document.querySelector(s);
  const $$ = (s) => [...document.querySelectorAll(s)];
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const store = {
    get(k, d) { try { const v = localStorage.getItem("nxtbot:" + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem("nxtbot:" + k, JSON.stringify(v)); } catch (e) {} },
  };
  const short = (a) => (a ? a.slice(0, 4) + "…" + a.slice(-4) : "");
  const fmtSol = (n, d = 4) => (n == null || isNaN(n) ? "—" : (+n).toFixed(d));
  const signed = (n, d = 4) => (n > 0 ? "+" : n < 0 ? "−" : "") + Math.abs(n).toFixed(d);
  const pct = (n) => (n > 0 ? "+" : n < 0 ? "−" : "") + Math.abs(n).toFixed(1) + "%";
  const fmtK = (n) => (n >= 1e6 ? (n / 1e6).toFixed(1) + "M" : n >= 1e3 ? (n / 1e3).toFixed(1) + "K" : Math.round(n) + "");
  const usd = (n) => (n == null ? "" : (n < 0 ? "−$" : "$") + Math.abs(n).toLocaleString(undefined, { maximumFractionDigits: 2, minimumFractionDigits: 2 }));
  function ago(ts) { const s = Math.max(0, (Date.now() - ts) / 1000); if (s < 60) return Math.floor(s) + "s"; if (s < 3600) return Math.floor(s / 60) + "m"; if (s < 86400) return Math.floor(s / 3600) + "h"; return Math.floor(s / 86400) + "d"; }
  function toast(m) { const t = $("#toast"); t.textContent = m; t.hidden = false; clearTimeout(toast._t); toast._t = setTimeout(() => (t.hidden = true), 3200); }
  function errMsg(e) {
    if (!e) return "unknown error";
    if (e.name === "AbortError") return "timed out";
    if (e.status === 429) return "rate limited, retrying soon";
    if (e.body) { try { const j = JSON.parse(e.body); if (j.error || j.message) return String(j.error || j.message).slice(0, 90); } catch (x) {} }
    return String(e.message || e).slice(0, 90);
  }

  /* ---------- base58 (for exporting/importing the bot key) ---------- */
  const B58 = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
  function b58enc(bytes) { let n = 0n; for (const b of bytes) n = n * 256n + BigInt(b); let s = ""; while (n > 0n) { s = B58[Number(n % 58n)] + s; n /= 58n; } for (const b of bytes) { if (b === 0) s = "1" + s; else break; } return s; }
  function b58dec(str) { let n = 0n; for (const c of str) { const i = B58.indexOf(c); if (i < 0) throw new Error("Not a valid key"); n = n * 58n + BigInt(i); } const out = []; while (n > 0n) { out.unshift(Number(n % 256n)); n /= 256n; } for (const c of str) { if (c === "1") out.unshift(0); else break; } return Uint8Array.from(out); }
  function b64(s) { const bin = atob(s); const u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u; }
  const isSolAddr = (a) => /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(a || "");

  /* ---------- state ---------- */
  const PRESETS = {
    any: { minScore: 0, minLiq: 1000, maxAge: 30, f: { mint: false, freeze: true, lp: false, top10: false, sell: true } },
    balanced: { minScore: 50, minLiq: 3000, maxAge: 45, f: { mint: true, freeze: true, lp: true, top10: false, sell: true } },
    strict: { minScore: 70, minLiq: 5000, maxAge: 60, f: { mint: true, freeze: true, lp: true, top10: true, sell: true } },
  };
  const PRESET_HINT = {
    any: "Buys every new coin it can sell back, as fast as your open-trade limit allows. Only coins that can freeze your tokens or can't be sold are skipped.",
    balanced: "Buys new coins with momentum 50+ that pass the main rug checks (mint, freeze, liquidity, sell route).",
    strict: "Buys only strong movers (70+) that pass every rug check, including whale concentration.",
  };
  const DEF = Object.assign({ size: 0.05, maxOpen: 5, slip: 15, prio: 1000000, tp: 100, tpSell: 50, sl: 30, trailOn: true, trail: 15, hold: 60, autoBuy: true }, JSON.parse(JSON.stringify(PRESETS.any)));
  let S = Object.assign({}, DEF, store.get("settings", {}));
  S.f = Object.assign({}, DEF.f, S.f || {});
  const liveOpen = () => Date.now() >= Date.parse(C.LAUNCH_AT || 0) || /preview/i.test(location.hash);
  let mode = store.get("mode", "paper");
  if (mode === "live" && !liveOpen()) mode = "paper";
  let running = false;
  const positions = { paper: store.get("pos:paper", []), live: store.get("pos:live", []) };
  const closed = { paper: store.get("closed:paper", []), live: store.get("closed:live", []) };
  let paperBal = store.get("paperBal", C.PRACTICE_START_SOL || 1);
  let log = store.get("log", []);
  let follows = store.get("follows", []);
  const blocked = new Set(store.get("blocked", []));
  const tried = new Set(store.get("tried", []));
  let main = null, provider = null, holder = false, botKp = null, botBal = null, solUsd = null;
  let scan = new Map(), scanOK = null, scanErr = "", lastScan = 0, scanFilter = "all";
  let wakeLock = null;
  const conn = W ? new W.Connection(C.SOLANA_RPC || "https://api.mainnet-beta.solana.com", "confirmed") : null;

  if (W) { const sk = store.get("botKey", null); if (sk) { try { botKp = W.Keypair.fromSecretKey(Uint8Array.from(sk)); } catch (e) {} } }

  const savePos = () => { store.set("pos:paper", positions.paper.map(clean)); store.set("pos:live", positions.live.map(clean)); };
  const clean = (p) => { const { selling, pending, ...rest } = p; return rest; };
  const saveClosed = () => { store.set("closed:paper", closed.paper.slice(-500)); store.set("closed:live", closed.live.slice(-500)); };
  const saveTried = () => store.set("tried", [...tried].slice(-600));
  const saveFollows = () => store.set("follows", follows);

  function addLog(k, t, sig, m) {
    log.unshift({ k, t, s: sig || null, at: Date.now(), m: m || mode });
    log = log.slice(0, 150); store.set("log", log); renderFeed();
  }

  /* ---------- network helpers ---------- */
  async function getJSON(url, opt = {}, ms = 15000) {
    const ac = new AbortController(); const t = setTimeout(() => ac.abort(), ms);
    try {
      const r = await fetch(url, Object.assign({}, opt, { signal: ac.signal }));
      if (!r.ok) { const e = new Error("HTTP " + r.status); e.status = r.status; e.body = await r.text().catch(() => ""); throw e; }
      return await r.json();
    } finally { clearTimeout(t); }
  }
  const jupBase = () => (C.JUPITER_API || "https://lite-api.jup.ag").replace(/\/$/, "");
  const jupHeaders = (post) => { const h = {}; if (post) h["content-type"] = "application/json"; if (C.JUPITER_KEY) h["x-api-key"] = C.JUPITER_KEY; return h; };
  function quote(inM, outM, amount) {
    return getJSON(`${jupBase()}/swap/v1/quote?inputMint=${inM}&outputMint=${outM}&amount=${amount}&slippageBps=${Math.round(S.slip * 100)}&restrictIntermediateTokens=true`, { headers: jupHeaders(false) });
  }
  async function execSwap(q) {
    const body = { quoteResponse: q, userPublicKey: botKp.publicKey.toBase58(), wrapAndUnwrapSol: true, dynamicComputeUnitLimit: true,
      prioritizationFeeLamports: { priorityLevelWithMaxLamports: { maxLamports: S.prio, priorityLevel: "veryHigh" } } };
    const r = await getJSON(`${jupBase()}/swap/v1/swap`, { method: "POST", headers: jupHeaders(true), body: JSON.stringify(body) }, 20000);
    const tx = W.VersionedTransaction.deserialize(b64(r.swapTransaction));
    tx.sign([botKp]);
    const sig = await conn.sendRawTransaction(tx.serialize(), { skipPreflight: true, maxRetries: 3 });
    await confirmSig(sig);
    return sig;
  }
  async function confirmSig(sig, ms = 60000) {
    const end = Date.now() + ms;
    while (Date.now() < end) {
      const { value } = await conn.getSignatureStatuses([sig]);
      const st = value && value[0];
      if (st) { if (st.err) throw new Error("Transaction failed on chain"); if (st.confirmationStatus === "confirmed" || st.confirmationStatus === "finalized") return; }
      await sleep(1500);
    }
    const e = new Error("Not confirmed within 60s"); e.timeout = true; e.sig = sig; throw e;
  }
  async function tokenBal(owner, mint) {
    const r = await conn.getParsedTokenAccountsByOwner(new W.PublicKey(owner), { mint: new W.PublicKey(mint) });
    let a = 0n, d = null;
    for (const x of r.value) { const i = x.account.data.parsed.info.tokenAmount; a += BigInt(i.amount); d = i.decimals; }
    return { amount: a, decimals: d };
  }
  const feeRate = (m) => { if (m === "live" && !C.TREASURY_SOL) return 0; return (holder ? C.FEE_HOLDER_BPS ?? 50 : C.FEE_STANDARD_BPS ?? 100) / 10000; };
  async function payFee(sol) {
    if (!C.TREASURY_SOL || !isSolAddr(C.TREASURY_SOL)) return;
    const lamports = Math.floor(sol * LAMPORTS); if (lamports < 5000) return;
    try {
      const tx = new W.Transaction().add(W.SystemProgram.transfer({ fromPubkey: botKp.publicKey, toPubkey: new W.PublicKey(C.TREASURY_SOL), lamports }));
      tx.feePayer = botKp.publicKey; tx.recentBlockhash = (await conn.getLatestBlockhash()).blockhash; tx.sign(botKp);
      await conn.sendRawTransaction(tx.serialize());
    } catch (e) { console.warn("fee transfer", e); }
  }
  async function refreshBotBal() {
    if (!botKp || !conn) return;
    try { botBal = (await conn.getBalance(botKp.publicKey)) / LAMPORTS; } catch (e) {}
    renderWallet();
  }
  async function refreshSolUsd() {
    try { const j = await getJSON(`${jupBase()}/price/v3?ids=${SOL}`, { headers: jupHeaders(false) }); const v = j[SOL] || (j.data && j.data[SOL]); solUsd = v ? +(v.usdPrice ?? v.price) : solUsd; } catch (e) {}
    renderStats();
  }

  /* ---------- trading ---------- */
  const isHeld = (mint) => positions.paper.some((p) => p.mint === mint && mode === "paper") || positions.live.some((p) => p.mint === mint && mode === "live");
  let tradeLock = Promise.resolve();
  const serial = (fn) => { const run = tradeLock.then(fn, fn); tradeLock = run.catch(() => {}); return run; };

  function buy(t, source) { return serial(() => doBuy(t, source, mode)); }
  async function doBuy(t, source, m) {
    const P = positions[m];
    if (P.some((p) => p.mint === t.mint)) return false;
    if (P.length >= S.maxOpen) { addLog("skip", `Skipped ${t.symbol}: already at ${S.maxOpen} open positions`, null, m); return false; }
    if (m === "live" && !liveOpen()) { addLog("skip", "Live trading opens Oct 3", null, m); return false; }
    const size = +S.size, fee = size * feeRate(m);
    if (m === "paper" && paperBal < size + fee) { addLog("skip", `Skipped ${t.symbol}: practice balance too low`, null, m); return false; }
    if (m === "live") {
      if (!botKp) { addLog("skip", `Skipped ${t.symbol}: create a bot wallet first`, null, m); return false; }
      await refreshBotBal();
      const need = size + fee + 0.004 + S.prio / LAMPORTS;
      if ((botBal ?? 0) < need) { addLog("skip", `Skipped ${t.symbol}: bot wallet needs ${need.toFixed(3)} SOL`, null, m); return false; }
    }
    tried.add(t.mint); saveTried();
    let q;
    try { q = await quote(SOL, t.mint, BigInt(Math.floor(size * LAMPORTS)).toString()); }
    catch (e) { addLog("err", `Couldn't price ${t.symbol}: ${errMsg(e)}`, null, m); return false; }
    let tokens = BigInt(q.outAmount), sig = null, decimals = t.decimals ?? null;
    if (m === "live") {
      const bot = botKp.publicKey.toBase58();
      try { sig = await execSwap(q); }
      catch (e) {
        let landed = false;
        try { const b = await tokenBal(bot, t.mint); if (b.amount > 0n) { tokens = b.amount; landed = true; sig = e.sig || null; } } catch (x) {}
        if (!landed) { addLog("err", `Buy of ${t.symbol} failed: ${errMsg(e)}`, e.sig, m); refreshBotBal(); return false; }
      }
      try { const b = await tokenBal(bot, t.mint); if (b.amount > 0n) tokens = b.amount; if (b.decimals != null) decimals = b.decimals; } catch (x) {}
      payFee(fee); refreshBotBal();
    } else { paperBal -= size + fee; store.set("paperBal", paperBal); }
    const p = { mint: t.mint, symbol: t.symbol, name: t.name || "", image: t.image || null, source, mode: m, cost: size, cost0: size, feePaid: fee, tokens: tokens.toString(), decimals,
      openedAt: Date.now(), value: size, peak: size, half: false, fails: 0, realized: 0 };
    P.push(p); savePos();
    const why = source.startsWith("copy:") ? `copied ${followLabel(source.slice(5))}` : source === "manual" ? "manual buy" : `score ${t.score}`;
    addLog("buy", `Bought ${t.symbol} for ${size} SOL · ${why}`, sig, m);
    renderAll();
    return true;
  }

  function sell(p, frac, reason, kind) { if (p.pending) return Promise.resolve(false); p.pending = true; return serial(() => doSell(p, frac, reason, kind)).finally(() => { p.pending = false; }); }
  async function doSell(p, frac, reason, kind) {
    const m = p.mode || "paper", P = positions[m];
    if (!P.includes(p) || p.selling) return false;
    p.selling = true;
    try {
      const total = BigInt(p.tokens);
      const amt = frac >= 1 ? total : (total * BigInt(Math.max(1, Math.round(frac * 10000)))) / 10000n;
      if (amt <= 0n) { P.splice(P.indexOf(p), 1); savePos(); renderAll(); return false; }
      let q;
      try { q = await quote(p.mint, SOL, amt.toString()); }
      catch (e) { addLog("err", `Couldn't sell ${p.symbol}: ${errMsg(e)}`, null, m); return false; }
      let solOut = Number(q.outAmount) / LAMPORTS, sig = null, remaining = total - amt;
      if (m === "live") {
        try { sig = await execSwap(q); }
        catch (e) {
          let landed = false;
          try { const b = await tokenBal(botKp.publicKey.toBase58(), p.mint); if (b.amount < total) { landed = true; remaining = b.amount; sig = e.sig || null; } } catch (x) {}
          if (!landed) { addLog("err", `Sell of ${p.symbol} failed: ${errMsg(e)}. Will retry.`, e.sig, m); return false; }
        }
        try { remaining = (await tokenBal(botKp.publicKey.toBase58(), p.mint)).amount; } catch (x) {}
      }
      const fee = solOut * feeRate(m);
      if (m === "paper") { paperBal += solOut - fee; store.set("paperBal", paperBal); } else { payFee(fee); refreshBotBal(); }
      const share = Number(amt) / Number(total);
      const costPart = p.cost * share, feePart = p.feePaid * share;
      const pnl = solOut - fee - costPart - feePart;
      p.realized += pnl; p.cost -= costPart; p.feePaid -= feePart; p.tokens = (remaining < 0n ? 0n : remaining).toString();
      p.value = p.value != null ? p.value * (1 - share) : null; p.peak = p.value || 0; if (frac < 1) p.half = true;
      addLog(kind, `${reason}: ${frac >= 1 ? "sold" : "sold " + Math.round(frac * 100) + "% of"} ${p.symbol} for ${solOut.toFixed(4)} SOL (${signed(pnl)} SOL)`, sig, m);
      if (frac >= 1 || BigInt(p.tokens) === 0n) {
        P.splice(P.indexOf(p), 1);
        closed[m].push({ symbol: p.symbol, mint: p.mint, pnl: p.realized, cost: p.cost0, at: Date.now(), reason, source: p.source });
        saveClosed();
      }
      savePos(); renderAll();
      return true;
    } finally { p.selling = false; }
  }

  let monitoring = false;
  async function monitor() {
    if (monitoring) return; monitoring = true;
    try {
    for (const m of ["paper", "live"]) {
      if (m === "live" && (!botKp || !conn)) continue;
      for (const p of [...positions[m]]) {
        if (p.selling || p.pending) continue;
        let v;
        try { const q = await quote(p.mint, SOL, p.tokens); v = Number(q.outAmount) / LAMPORTS; p.fails = 0; }
        catch (e) { p.fails = (p.fails || 0) + 1; if (p.fails === 5) addLog("err", `No sell price for ${p.symbol} (${errMsg(e)}). It may not be sellable.`, null, m); continue; }
        p.value = v; p.peak = Math.max(p.peak || 0, v); p.checkedAt = Date.now();
        const ch = p.cost > 0 ? v / p.cost - 1 : 0;
        if (ch <= -S.sl / 100) { await sell(p, 1, "Stop-loss", "sl"); continue; }
        if (!p.half && ch >= S.tp / 100) {
          await sell(p, Math.min(100, Math.max(1, S.tpSell || 100)) / 100, "Take-profit", "tp");
          continue;
        }
        if (p.half && S.trailOn && v <= p.peak * (1 - S.trail / 100)) { await sell(p, 1, "Trailing stop", "sell"); continue; }
        if (S.hold && Date.now() - p.openedAt > S.hold * 60000) { await sell(p, 1, "Max hold time", "sell"); continue; }
        await sleep(250);
      }
    }
    } finally { monitoring = false; }
    savePos(); renderPositions(); renderStats();
  }

  /* ---------- scanner ---------- */
  const CHK = {
    mint: { label: "Mint", bad: "Mint not revoked" },
    freeze: { label: "Freeze", bad: "Can freeze tokens" },
    lp: { label: "LP", bad: "Liquidity unlocked" },
    top10: { label: "Holders", bad: "Whale concentration" },
    sell: { label: "Sell", bad: "No sell route" },
  };
  function momentum(t) {
    const tot = t.buys5 + t.sells5;
    const pressure = tot ? t.buys5 / tot : 0;
    let sc = Math.min(30, Math.max(0, (pressure - 0.4) / 0.4) * 30);
    sc += Math.min(t.buyers5 / 40, 1) * 25;
    sc += Math.min(t.vol5 / Math.max(t.liq, 1) / 0.5, 1) * 20;
    const ch = t.ch5; sc += ch <= 0 ? 0 : ch <= 60 ? (ch / 60) * 15 : Math.max(0, 15 - (ch - 60) / 10);
    sc += Math.min(t.liq / 30000, 1) * 10;
    return Math.round(Math.min(100, sc));
  }
  async function rugApi(mint) {
    const base = (C.RUGCHECK_API || "/api/rug").replace(/\/$/, "");
    const url = /rugcheck\.xyz/.test(base) ? `${base}/v1/tokens/${mint}/report/summary` : `${base}?mint=${mint}`;
    return getJSON(url, { headers: { accept: "application/json" } }, 12000);
  }
  async function rugCheck(it) {
    const r = { mint: null, freeze: null, lp: null, top10: null, sell: null, danger: [] };
    try {
      const info = await conn.getParsedAccountInfo(new W.PublicKey(it.mint));
      const p = info.value && info.value.data && info.value.data.parsed && info.value.data.parsed.info;
      if (p) { r.mint = !p.mintAuthority; r.freeze = !p.freezeAuthority; it.decimals = p.decimals; }
    } catch (e) {}
    try {
      const d = await rugApi(it.mint);
      const risks = (d.risks || []).map((x) => `${x.name || ""} ${x.description || ""}`);
      const lpRisk = risks.some((s) => /LP Unlocked|liquidity.*unlock/i.test(s));
      if (CURVE_DEX.test(it.dex || "")) r.lp = true;
      else r.lp = typeof d.lpLockedPct === "number" ? d.lpLockedPct >= 80 && !lpRisk : !lpRisk;
      r.top10 = !risks.some((s) => /top 10|single holder|high ownership|high holder|concentrat/i.test(s));
      if (r.mint == null && risks.some((s) => /mint authority/i.test(s))) r.mint = false;
      if (r.freeze == null && risks.some((s) => /freeze authority/i.test(s))) r.freeze = false;
      r.danger = (d.risks || []).filter((x) => x.level === "danger").map((x) => x.name);
    } catch (e) { if (CURVE_DEX.test(it.dex || "")) r.lp = true; }
    if (it.decimals != null) {
      try { await quote(it.mint, SOL, (10n ** BigInt(it.decimals) * 1000n).toString()); r.sell = true; }
      catch (e) { r.sell = e.status === 400 ? false : null; }
    }
    return r;
  }
  function verdict(it) {
    if (isHeld(it.mint)) return { v: "held", why: "In your positions" };
    const why = [];
    if (it.checks) for (const k in CHK) if (S.f[k] && it.checks[k] === false) why.push(CHK[k].bad);
    if (why.length) return { v: "fail", why: why.join(", ") };
    if (!it.checks) return { v: "watch", why: it.liq < S.minLiq ? `Liquidity under $${fmtK(S.minLiq)}` : "Checking…" };
    const unk = Object.keys(CHK).filter((k) => S.f[k] && it.checks[k] == null);
    if (unk.length) return { v: "watch", why: "Couldn't check " + unk.map((k) => CHK[k].label).join(", ") };
    if (it.liq < S.minLiq) return { v: "watch", why: `Liquidity under $${fmtK(S.minLiq)}` };
    if ((Date.now() - it.created) / 60000 > S.maxAge) return { v: "watch", why: `Older than ${S.maxAge} min` };
    if (it.score < S.minScore) return { v: "watch", why: `Score under ${S.minScore}` };
    return { v: "pass", why: "" };
  }
  let scanning = false;
  async function runScan() {
    if (scanning || !conn) return; scanning = true;
    try {
      const base = (C.GECKO_API || "https://api.geckoterminal.com/api/v2").replace(/\/$/, "");
      const pages = [];
      for (const pg of [1, 2]) {
        try { pages.push(await getJSON(`${base}/networks/solana/new_pools?page=${pg}&include=base_token,quote_token`, { headers: { accept: "application/json" } })); }
        catch (e) { if (pg === 1) throw e; }
      }
      const inc = {}; const data = [];
      pages.forEach((j) => { (j.included || []).forEach((x) => (inc[x.id] = x.attributes || {})); data.push(...(j.data || [])); });
      for (const pool of data) {
        const a = pool.attributes || {}, rel = pool.relationships || {};
        const bId = (rel.base_token && rel.base_token.data && rel.base_token.data.id) || "";
        const qId = (rel.quote_token && rel.quote_token.data && rel.quote_token.data.id) || "";
        const bt = inc[bId] || {}, qt = inc[qId] || {};
        const mint = bt.address || bId.replace(/^solana_/, ""), qm = qt.address || qId.replace(/^solana_/, "");
        if (!isSolAddr(mint) || STABLE.has(mint) || !STABLE.has(qm)) continue;
        const tx5 = (a.transactions && a.transactions.m5) || {};
        const it = scan.get(mint) || { mint, checks: null };
        Object.assign(it, {
          pool: a.address, symbol: (bt.symbol || (a.name || "").split(" / ")[0] || mint.slice(0, 4)).slice(0, 14), name: (bt.name || a.name || "").slice(0, 40),
          image: /^https:\/\//.test(bt.image_url || "") ? bt.image_url : null, created: Date.parse(a.pool_created_at) || Date.now(),
          liq: +a.reserve_in_usd || 0, vol5: +((a.volume_usd || {}).m5) || 0, buys5: +tx5.buys || 0, sells5: +tx5.sells || 0, buyers5: +tx5.buyers || 0,
          ch5: +((a.price_change_percentage || {}).m5) || 0, dex: (rel.dex && rel.dex.data && rel.dex.data.id) || "",
        });
        if (it.decimals == null && bt.decimals != null) it.decimals = +bt.decimals;
        it.score = momentum(it);
        scan.set(mint, it);
      }
      const keep = [...scan.values()].sort((x, y) => y.created - x.created).slice(0, 60);
      scan = new Map(keep.map((x) => [x.mint, x]));
      scanOK = true; lastScan = Date.now();
    } catch (e) { scanOK = false; scanErr = errMsg(e); }
    renderScan();
    try {
      const queue = [...scan.values()].filter((x) => !x.checks && !x.checking && x.liq >= S.minLiq * 0.5 && (Date.now() - x.created) / 60000 <= S.maxAge).sort((a, b) => b.created - a.created).slice(0, 8);
      for (const it of queue) {
        it.checking = true;
        it.checks = await rugCheck(it); it.checking = false;
        if (Object.keys(CHK).some((k) => S.f[k] && it.checks[k] === false)) { blocked.add(it.mint); store.set("blocked", [...blocked].slice(-2000)); }
        renderScan(); renderStats();
        await sleep(400);
      }
    } catch (e) {}
    if (running && S.autoBuy) {
      const cands = [...scan.values()].filter((x) => !tried.has(x.mint) && verdict(x).v === "pass").sort((a, b) => b.score - a.score || b.created - a.created);
      for (const c of cands) {
        if (!running || positions[mode].length >= S.maxOpen) break;
        await buy(c, "scan");
      }
    }
    scanning = false;
  }

  /* ---------- copy trading ---------- */
  const followLabel = (addr) => { const f = follows.find((x) => x.addr === addr); return f && f.name ? f.name : short(addr); };
  async function tokenMeta(mint) {
    const s = scan.get(mint); if (s) return s;
    const it = { mint, symbol: mint.slice(0, 4), name: "", image: null, dex: "", created: Date.now(), liq: 0, score: 0 };
    try {
      const j = await getJSON(`${(C.GECKO_API || "").replace(/\/$/, "")}/networks/solana/tokens/${mint}`, { headers: { accept: "application/json" } });
      const a = (j.data && j.data.attributes) || {};
      it.symbol = (a.symbol || it.symbol).slice(0, 14); it.name = (a.name || "").slice(0, 40);
      it.image = /^https:\/\//.test(a.image_url || "") ? a.image_url : null; if (a.decimals != null) it.decimals = +a.decimals;
    } catch (e) {}
    return it;
  }
  async function copyBuy(f, mint) {
    if (isHeld(mint) || tried.has(mint + ":" + f.addr)) return;
    tried.add(mint + ":" + f.addr); saveTried();
    const it = await tokenMeta(mint);
    const chk = it.checks || (it.checks = await rugCheck(it));
    const bad = Object.keys(CHK).filter((k) => S.f[k] && chk[k] === false).map((k) => CHK[k].bad);
    if (bad.length) { addLog("skip", `Didn't copy ${followLabel(f.addr)} into ${it.symbol}: ${bad.join(", ")}`); blocked.add(mint); return; }
    const unk = Object.keys(CHK).filter((k) => S.f[k] && chk[k] == null).map((k) => CHK[k].label);
    if (unk.length) { addLog("skip", `Didn't copy ${followLabel(f.addr)} into ${it.symbol}: couldn't check ${unk.join(", ")}`); return; }
    const ok = await buy(it, "copy:" + f.addr);
    if (ok) { f.buys = (f.buys || 0) + 1; saveFollows(); renderCopy(); }
  }
  let copying = false;
  async function copyTick() {
    if (copying || !conn || !running || !follows.length) return; copying = true;
    try {
      for (const f of follows) {
        try {
          const sigs = await conn.getSignaturesForAddress(new W.PublicKey(f.addr), { limit: 10 });
          if (!f.last) { f.last = (sigs[0] && sigs[0].signature) || "none"; saveFollows(); continue; }
          const fresh = []; for (const s of sigs) { if (s.signature === f.last) break; fresh.push(s); }
          if (!fresh.length) continue;
          f.last = sigs[0].signature; f.err = null; saveFollows();
          for (const s of fresh.reverse()) {
            if (s.err) continue;
            const tx = await conn.getParsedTransaction(s.signature, { maxSupportedTransactionVersion: 0, commitment: "confirmed" });
            if (!tx || !tx.meta || tx.meta.err) continue;
            const d = new Map();
            const add = (arr, sign) => (arr || []).forEach((b) => { if (b.owner !== f.addr) return; d.set(b.mint, (d.get(b.mint) || 0n) + sign * BigInt(b.uiTokenAmount.amount)); });
            add(tx.meta.preTokenBalances, -1n); add(tx.meta.postTokenBalances, 1n);
            for (const [mint, delta] of d) {
              if (STABLE.has(mint)) continue;
              if (delta > 0n) await copyBuy(f, mint);
              else if (delta < 0n && f.mirror) {
                const p = positions[mode].find((x) => x.mint === mint && x.source === "copy:" + f.addr);
                if (p) await sell(p, 1, `${followLabel(f.addr)} sold`, "sell");
              }
            }
            await sleep(300);
          }
        } catch (e) { f.err = errMsg(e); }
      }
    } finally { copying = false; renderCopy(); }
  }

  /* ---------- wallets ---------- */
  function providers() {
    return [
      { n: "Phantom", bg: "#ab9ff2", l: "P", p: (window.phantom && window.phantom.solana) || (window.solana && window.solana.isPhantom ? window.solana : null) },
      { n: "Solflare", bg: "#fc7227", l: "S", p: window.solflare && window.solflare.isSolflare ? window.solflare : null },
      { n: "Backpack", bg: "#e33e3f", l: "B", p: window.backpack || null },
    ];
  }
  function openConnect() {
    if (main) {
      modal("Wallet", `<div class="addr"><span>${esc(main)}</span></div><p>${holder ? "NXT holder: you get the 0.5% bot fee." : C.NXT_TOKEN && C.NXT_TOKEN.address ? "No NXT found in this wallet. Hold any amount for the 0.5% fee." : "The NXT holder discount turns on when NXT launches."}</p><button class="btn danger" type="button" id="m-disc">Disconnect</button>`);
      $("#m-disc").onclick = () => { try { provider && provider.disconnect && provider.disconnect(); } catch (e) {} main = null; provider = null; holder = false; closeModal(); renderHeader(); renderFee(); };
      return;
    }
    const list = providers();
    const any = list.some((x) => x.p);
    const deep = `https://phantom.app/ul/browse/${encodeURIComponent(location.href)}?ref=${encodeURIComponent(location.origin)}`;
    modal("Connect wallet", list.map((w, i) => `<button class="witem" type="button" data-w="${i}"><span class="wi" style="background:${w.bg}">${w.l}</span><span><b>${w.n}</b><small>${w.p ? "Detected" : "Not installed"}</small></span><span class="st">${w.p ? "Connect" : ""}</span></button>`).join("") +
      (any ? "" : `<p>On a phone, open this site inside your wallet's own browser. <a href="${esc(deep)}" rel="noopener">Open in Phantom</a></p>`) +
      `<p class="hint">Your main wallet is used to fund the bot wallet, receive withdrawals and check for NXT. The bot never trades from it.</p>`);
    $$("#m-body [data-w]").forEach((b) => (b.onclick = async () => {
      const w = list[+b.dataset.w];
      if (!w.p) { toast(w.n + " isn't installed in this browser"); return; }
      try { const r = await w.p.connect(); const pk = (r && r.publicKey) || w.p.publicKey; main = pk.toString(); provider = w.p; closeModal(); renderHeader(); toast("Connected " + w.n); checkHolder(); }
      catch (e) { toast("Connection cancelled"); }
    }));
  }
  async function checkHolder() {
    holder = false;
    const mint = C.NXT_TOKEN && C.NXT_TOKEN.address;
    if (mint && isSolAddr(mint) && conn) {
      for (const o of [main, botKp && botKp.publicKey.toBase58()].filter(Boolean)) {
        try { const b = await tokenBal(o, mint); if (b.amount > 0n) { holder = true; break; } } catch (e) {}
      }
    }
    renderFee();
  }
  function createBot() {
    botKp = W.Keypair.generate(); store.set("botKey", Array.from(botKp.secretKey)); botBal = 0;
    addLog("sell", "Created bot wallet " + short(botKp.publicKey.toBase58()));
    renderWallet(); showExport(true);
  }
  function showExport(fresh) {
    const k = b58enc(botKp.secretKey);
    modal(fresh ? "Back up your bot key" : "Bot wallet key",
      `<div class="warnbox">${fresh ? "Your bot wallet was created on this device. " : ""}This key controls every coin in the bot wallet. Anyone with it can take them. Save it in a password manager, and never share it or paste it into a website you don't trust.</div>
       <div class="secret" id="m-secret">${esc(k)}</div>
       <div class="btn-row" style="grid-template-columns:1fr 1fr"><button class="btn" type="button" id="m-reveal">Reveal</button><button class="btn accent" type="button" id="m-copy">Copy key</button></div>
       <p class="hint">You can import this key into Phantom (Add account → Import private key) to see the bot wallet there.</p>`);
    $("#m-reveal").onclick = () => $("#m-secret").classList.toggle("show");
    $("#m-copy").onclick = () => copyText(k, "Key copied");
  }
  function showImport() {
    modal("Import bot key", `${botKp ? `<div class="warnbox">This replaces the current bot wallet on this device. Export its key first if it still holds anything.</div>` : ""}
      <label for="m-key">Private key <small>base58 or a JSON array</small><textarea id="m-key" spellcheck="false" autocomplete="off"></textarea></label>
      <p class="err" id="m-kerr" hidden></p><button class="cta" type="button" id="m-kgo">Import</button>`);
    $("#m-kgo").onclick = () => {
      const v = $("#m-key").value.trim(); let bytes;
      try { bytes = v.startsWith("[") ? Uint8Array.from(JSON.parse(v)) : b58dec(v); const kp = W.Keypair.fromSecretKey(bytes); botKp = kp; }
      catch (e) { const er = $("#m-kerr"); er.textContent = "That key isn't valid. Paste the full 64-byte private key."; er.hidden = false; return; }
      store.set("botKey", Array.from(botKp.secretKey)); closeModal(); toast("Bot wallet imported"); refreshBotBal(); checkHolder();
    };
  }
  async function sendFromMain(lamports) {
    const tx = new W.Transaction().add(W.SystemProgram.transfer({ fromPubkey: new W.PublicKey(main), toPubkey: botKp.publicKey, lamports }));
    tx.feePayer = new W.PublicKey(main); tx.recentBlockhash = (await conn.getLatestBlockhash()).blockhash;
    if (provider.signAndSendTransaction) { const r = await provider.signAndSendTransaction(tx); return r.signature || r; }
    const signed = await provider.signTransaction(tx); return conn.sendRawTransaction(signed.serialize());
  }
  function showDeposit() {
    if (!main) { toast("Connect your main wallet first"); openConnect(); return; }
    modal("Fund bot wallet", `<p>Send SOL from ${esc(short(main))} to your bot wallet. Keep extra for fees: about 0.005 SOL per trade.</p>
      <label for="m-amt">Amount<div class="suffix"><input type="number" id="m-amt" step="0.05" min="0.01" value="0.25"><span>SOL</span></div></label>
      <div class="quick">${[0.1, 0.25, 0.5, 1].map((v) => `<button type="button" data-a="${v}">${v} SOL</button>`).join("")}</div>
      <p class="err" id="m-derr" hidden></p><button class="cta" type="button" id="m-dgo">Send from wallet</button>`);
    $$("#m-body [data-a]").forEach((b) => (b.onclick = () => ($("#m-amt").value = b.dataset.a)));
    $("#m-dgo").onclick = async () => {
      const a = +$("#m-amt").value; const er = $("#m-derr");
      if (!(a > 0)) { er.textContent = "Enter an amount above 0."; er.hidden = false; return; }
      const b = $("#m-dgo"); b.disabled = true; b.textContent = "Approve in your wallet…";
      try { const sig = await sendFromMain(Math.floor(a * LAMPORTS)); closeModal(); addLog("buy", `Funded bot wallet with ${a} SOL`, typeof sig === "string" ? sig : null, "live"); toast("Deposit sent"); setTimeout(refreshBotBal, 4000); setTimeout(refreshBotBal, 12000); }
      catch (e) { er.textContent = "Deposit cancelled or failed: " + errMsg(e); er.hidden = false; b.disabled = false; b.textContent = "Send from wallet"; }
    };
  }
  function showWithdraw() {
    const open = positions.live.length;
    modal("Withdraw SOL", `${open ? `<div class="warnbox">You have ${open} open live position${open > 1 ? "s" : ""}. Their coins stay in the bot wallet. Sell them first to withdraw everything.</div>` : ""}
      <label for="m-to">Send to<input type="text" id="m-to" value="${esc(main || "")}" placeholder="Solana address" spellcheck="false" autocomplete="off"></label>
      <label for="m-wamt">Amount <small>balance ${fmtSol(botBal)} SOL</small><div class="suffix"><input type="number" id="m-wamt" step="0.01" min="0" value="${botBal ? Math.max(0, botBal - 0.00001).toFixed(6) : ""}"><span>SOL</span></div></label>
      <p class="err" id="m-werr" hidden></p><button class="cta" type="button" id="m-wgo">Withdraw</button>`);
    $("#m-wgo").onclick = async () => {
      const to = $("#m-to").value.trim(), a = +$("#m-wamt").value, er = $("#m-werr");
      if (!isSolAddr(to)) { er.textContent = "Enter a valid Solana address."; er.hidden = false; return; }
      await refreshBotBal();
      const lam = Math.min(Math.floor(a * LAMPORTS), Math.floor((botBal || 0) * LAMPORTS) - 5000);
      if (!(lam > 0)) { er.textContent = "Not enough SOL to withdraw after the network fee."; er.hidden = false; return; }
      const b = $("#m-wgo"); b.disabled = true; b.textContent = "Sending…";
      try {
        const tx = new W.Transaction().add(W.SystemProgram.transfer({ fromPubkey: botKp.publicKey, toPubkey: new W.PublicKey(to), lamports: lam }));
        tx.feePayer = botKp.publicKey; tx.recentBlockhash = (await conn.getLatestBlockhash()).blockhash; tx.sign(botKp);
        const sig = await conn.sendRawTransaction(tx.serialize()); await confirmSig(sig);
        closeModal(); addLog("sell", `Withdrew ${(lam / LAMPORTS).toFixed(4)} SOL to ${short(to)}`, sig, "live"); toast("Withdrawn"); refreshBotBal();
      } catch (e) { er.textContent = "Withdrawal failed: " + errMsg(e); er.hidden = false; b.disabled = false; b.textContent = "Withdraw"; }
    };
  }
  function copyText(t, msg) {
    const done = () => toast(msg || "Copied");
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(t).then(done, () => fallbackCopy(t, done)); else fallbackCopy(t, done);
  }
  function fallbackCopy(t, done) { const a = document.createElement("textarea"); a.value = t; document.body.appendChild(a); a.select(); try { document.execCommand("copy"); done(); } catch (e) { toast("Select the text and copy it"); } a.remove(); }

  /* ---------- modal ---------- */
  function modal(title, html) { $("#m-title").textContent = title; $("#m-body").innerHTML = html; $("#scrim").hidden = false; const f = $("#m-body button, #m-body input, #m-body textarea"); if (f) setTimeout(() => f.focus(), 30); }
  function closeModal() { $("#scrim").hidden = true; $("#m-body").innerHTML = ""; }
  $("#scrim").addEventListener("click", (e) => { if (e.target.id === "scrim" || e.target.closest("[data-close]")) closeModal(); });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !$("#scrim").hidden) closeModal(); });

  /* ---------- engine & mode ---------- */
  async function setRunning(on) {
    if (on) {
      if (!conn) { toast("The Solana library didn't load. Refresh the page."); return; }
      if (mode === "live") {
        if (!liveOpen()) { toast("Live trading opens Oct 3. Practice mode is open now."); return; }
        if (!botKp) { toast("Create a bot wallet first"); return; }
        await refreshBotBal();
        if ((botBal || 0) < S.size + 0.01) { toast(`Fund the bot wallet with at least ${(S.size + 0.01).toFixed(2)} SOL`); showDeposit(); return; }
      }
      running = true; addLog("tp", `Bot started · ${mode === "live" ? "live" : "practice"} mode`);
      try { if (navigator.wakeLock) wakeLock = await navigator.wakeLock.request("screen"); } catch (e) {}
      runScan(); copyTick();
    } else {
      running = false; addLog("skip", "Bot stopped. Open positions keep their take-profit and stop-loss while this page is open.");
      try { wakeLock && wakeLock.release(); } catch (e) {} wakeLock = null;
    }
    renderEngine();
  }
  $("#engine-btn").addEventListener("click", () => setRunning(!running));
  $$(".mode button").forEach((b) => b.addEventListener("click", () => {
    const m = b.dataset.mode; if (m === mode) return;
    if (m === "live") {
      if (!liveOpen()) { toast("Live trading opens Oct 3. Practice mode is open now."); return; }
      modal("Switch to live trading?", `<p>Live mode spends real SOL from your bot wallet on new coins. Most new coins lose value quickly, and stop-losses can fill far below your setting when a coin crashes fast.</p>
        <p>Start small. Only fund the bot wallet with what you can afford to lose.</p><button class="cta" type="button" id="m-live">Switch to live</button>`);
      $("#m-live").onclick = () => { closeModal(); applyMode("live"); };
    } else applyMode("paper");
  }));
  function applyMode(m) { if (running) setRunning(false); mode = m; store.set("mode", m); renderAll(); if (m === "live" && botKp) refreshBotBal(); }

  /* ---------- rendering ---------- */
  function tokIcon(p) { const bg = ["#35f0ff", "#2fb3ff", "#7b61ff", "#3dffa8", "#ffd84d", "#ff8fd6", "#a8e1ff"][[...(p.mint || p.symbol || "x")].reduce((a, c) => a + c.charCodeAt(0), 0) % 7];
    return `<span class="ticon" style="background:${bg}">${p.image ? `<img src="${esc(p.image)}" alt="" loading="lazy" referrerpolicy="no-referrer" onerror="this.remove()">` : ""}${p.image ? "" : esc((p.symbol || "?").slice(0, 3))}</span>`; }
  const solscanTok = (m) => `https://solscan.io/token/${m}`;

  function renderHeader() { const b = $("#wallet-btn"); if (main) { b.textContent = short(main); b.classList.add("connected"); } else { b.textContent = "Connect"; b.classList.remove("connected"); } }
  function renderStatus() {
    const s = $("#status"), t = $("#status-text");
    if (!W) { t.textContent = "Couldn't load the Solana library. Check your connection and refresh."; return; }
    const d = Date.parse(C.LAUNCH_AT || 0) - Date.now();
    if (d > 0 && !/preview/i.test(location.hash)) {
      const dd = Math.floor(d / 864e5), hh = Math.floor((d % 864e5) / 36e5), mm = Math.floor((d % 36e5) / 6e4);
      s.classList.remove("live"); t.textContent = `Practice mode is open · live trading opens Oct 3 · ${dd}d ${hh}h ${mm}m`;
    } else { s.classList.add("live"); t.textContent = "NXT Bot is live on Solana · 0.5% fee for NXT holders"; }
  }
  function renderEngine() {
    $("#engine").classList.toggle("on", running);
    $("#engine-state").textContent = running ? (mode === "live" ? "Running · live" : "Running · practice") : "Stopped";
    const b = $("#engine-btn"); b.textContent = running ? "Stop bot" : mode === "live" ? "Start live bot" : "Start practice bot"; b.classList.toggle("stop", running);
    $$(".mode button").forEach((x) => { x.setAttribute("aria-pressed", x.dataset.mode === mode); if (x.dataset.mode === "live") x.textContent = liveOpen() ? "Live" : "Live · Oct 3"; });
    const pill = $("#mode-pill"); pill.className = "pill " + (mode === "live" ? "live" : "paper"); pill.textContent = mode === "live" ? "Live trading" : "Practice mode";
    $("#e-max").textContent = `${S.maxOpen} at a time${follows.length ? ` · copying ${follows.length}` : ""}`;
    fillQuick();
    renderFee();
  }
  function renderFee() {
    const std = (C.FEE_STANDARD_BPS ?? 100) / 100, hold = (C.FEE_HOLDER_BPS ?? 50) / 100;
    $("#fee-std").textContent = std.toFixed(1) + "% per trade"; $("#fee-hold").textContent = hold.toFixed(1) + "% per trade";
    const you = (holder ? hold : std).toFixed(1) + "%" + (holder ? " · NXT holder" : "");
    $("#fee-you").textContent = you; $("#e-fee").textContent = you; $("#e-fee").className = holder ? "free" : "";
  }
  function renderWallet() {
    const acts = $("#wc-actions"), pill = $("#wc-pill");
    if (mode === "paper") {
      $("#wc-title").textContent = "Practice wallet"; pill.className = "pill paper"; pill.textContent = "Not real SOL";
      $("#wc-bal").innerHTML = `${fmtSol(paperBal, 3)}<small>SOL</small>`; $("#wc-addr-row").hidden = true;
      acts.style.gridTemplateColumns = "1fr"; acts.innerHTML = `<button class="btn" type="button" id="w-reset">Reset practice account</button>`;
      $("#wc-hint").textContent = "Practice trades use real prices and real rug checks, with pretend SOL.";
      $("#w-reset").onclick = () => {
        modal("Reset practice account?", `<p>This sets the practice balance back to ${C.PRACTICE_START_SOL || 1} SOL and clears practice positions and history.</p><button class="cta" type="button" id="m-rs">Reset</button>`);
        $("#m-rs").onclick = () => { paperBal = C.PRACTICE_START_SOL || 1; positions.paper = []; closed.paper = []; store.set("paperBal", paperBal); savePos(); saveClosed(); closeModal(); renderAll(); toast("Practice account reset"); };
      };
      return;
    }
    $("#wc-title").textContent = "Bot wallet"; pill.className = "pill live"; pill.textContent = "Your key";
    if (!botKp) {
      $("#wc-bal").innerHTML = `<span style="font-size:18px">No bot wallet yet</span>`; $("#wc-addr-row").hidden = true;
      acts.style.gridTemplateColumns = "1fr 1fr"; acts.innerHTML = `<button class="btn accent" type="button" id="w-new">Create</button><button class="btn" type="button" id="w-imp">Import key</button>`;
      $("#wc-hint").textContent = "The bot trades from its own wallet so it can act without asking you to approve every trade. The key is made and kept on this device only.";
      $("#w-new").onclick = createBot; $("#w-imp").onclick = showImport; return;
    }
    const a = botKp.publicKey.toBase58();
    $("#wc-bal").innerHTML = `${fmtSol(botBal, 3)}<small>SOL${solUsd && botBal != null ? " · " + usd(botBal * solUsd) : ""}</small>`;
    $("#wc-addr-row").hidden = false; $("#wc-addr").textContent = a;
    acts.style.gridTemplateColumns = "repeat(3,1fr)";
    acts.innerHTML = `<button class="btn accent" type="button" id="w-dep">Deposit</button><button class="btn" type="button" id="w-wd">Withdraw</button><button class="btn" type="button" id="w-exp">Export key</button>`;
    $("#wc-hint").textContent = "Only you hold this key. It's saved in this browser, so back it up with Export key. Clearing site data deletes it.";
    $("#w-dep").onclick = showDeposit; $("#w-wd").onclick = showWithdraw; $("#w-exp").onclick = () => showExport(false);
  }
  $("#wc-copy").addEventListener("click", () => botKp && copyText(botKp.publicKey.toBase58(), "Address copied"));

  function renderStats() {
    const cl = closed[mode];
    const total = cl.reduce((a, c) => a + c.pnl, 0), cost = cl.reduce((a, c) => a + c.cost, 0);
    const el = $("#pnl"); el.textContent = `${signed(total, 3)} SOL`; el.className = "pnl " + (total > 0 ? "up" : total < 0 ? "down" : "");
    $("#pnl-label").textContent = `Realized P&L · ${mode === "live" ? "live" : "practice"}`;
    $("#pnl-sub").innerHTML = cl.length ? `<span class="${total >= 0 ? "up" : "down"}">${pct(cost ? (total / cost) * 100 : 0)}</span> <span class="muted">on ${fmtSol(cost, 2)} SOL traded${solUsd ? " · " + usd(total * solUsd) : ""}</span>` : `<span class="muted">No closed trades yet</span>`;
    $("#f-trades").textContent = cl.length;
    $("#f-win").textContent = cl.length ? Math.round((cl.filter((c) => c.pnl > 0).length / cl.length) * 100) + "%" : "—";
    $("#f-open").textContent = positions[mode].length;
    $("#f-blocked").textContent = blocked.size;
    renderChart(cl);
  }
  function renderChart(cl) {
    const box = $("#chart-box");
    if (cl.length < 2) { box.innerHTML = `<div class="chart-empty">Your P&amp;L line fills in as trades close.${mode === "paper" ? " Start the practice bot to see it work." : ""}</div>`; return; }
    const pts = [0]; let run = 0; for (const c of [...cl].sort((a, b) => a.at - b.at)) { run += c.pnl; pts.push(run); }
    const W_ = 640, H = 210, pad = 12, n = pts.length, min = Math.min(...pts, 0), max = Math.max(...pts, 0);
    const sx = (i) => (i / (n - 1)) * (W_ - 10), sy = (v) => pad + ((max - v) / (max - min || 1)) * (H - 2 * pad);
    const line = pts.map((v, i) => `${sx(i).toFixed(1)},${sy(v).toFixed(1)}`).join(" ");
    const last = pts[n - 1], col = last >= 0 ? "#3dffa8" : "#ff5c7a";
    let grid = ""; for (let g = 1; g < 4; g++) grid += `<line x1="0" x2="${W_}" y1="${(H * g) / 4}" y2="${(H * g) / 4}" stroke="#16243a"/>`;
    box.innerHTML = `<svg class="chart" viewBox="0 0 ${W_} ${H}" preserveAspectRatio="none" role="img" aria-label="Cumulative realized profit and loss"><defs><linearGradient id="fg" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="${col}" stop-opacity=".28"/><stop offset="1" stop-color="${col}" stop-opacity="0"/></linearGradient></defs>${grid}
      <line x1="0" x2="${W_}" y1="${sy(0)}" y2="${sy(0)}" stroke="#22385a" stroke-dasharray="4 4"/>
      <polygon points="0,${sy(0)} ${line} ${sx(n - 1)},${sy(0)}" fill="url(#fg)"/>
      <polyline points="${line}" fill="none" stroke="${col}" stroke-width="2.4" vector-effect="non-scaling-stroke" stroke-linejoin="round"/>
      <circle cx="${sx(n - 1)}" cy="${sy(last)}" r="5" fill="${col}"/></svg>`;
  }
  function tpslBar(p) {
    const ch = p.value != null && p.cost ? (p.value / p.cost - 1) * 100 : 0, lo = -S.sl, hi = S.tp;
    const x = Math.max(0, Math.min(100, ((ch - lo) / (hi - lo)) * 100));
    return `<div class="tpsl"><div class="track"><i style="left:calc(${x}% - 1.5px)"></i></div><small><span>SL −${S.sl}%</span><span>${p.half ? (S.trailOn ? "Trailing" : "TP hit") : "TP +" + S.tp + "%"}</span></small></div>`;
  }
  function renderPositions() {
    const P = positions[mode];
    let unreal = 0;
    const rows = P.map((p) => {
      const ch = p.value != null && p.cost ? (p.value / p.cost - 1) * 100 : null; const d = p.value != null ? p.value - p.cost : null; if (d != null) unreal += d;
      const src = p.source && p.source.startsWith("copy:") ? "Copied " + followLabel(p.source.slice(5)) : p.source === "manual" ? "Manual" : "Scanner";
      return { p, ch, d, src };
    });
    $("#pos-body").innerHTML = rows.map(({ p, ch, d, src }) => `<tr>
      <td><div class="tk">${tokIcon(p)}<div><b><a href="${solscanTok(p.mint)}" target="_blank" rel="noopener" style="color:inherit;text-decoration:none">${esc(p.symbol)}</a></b><small>${esc(src)}${p.half ? " · take-profit hit" : ""}</small></div></div></td>
      <td>${fmtSol(p.cost)}</td><td>${p.value != null ? fmtSol(p.value) : "…"}</td>
      <td class="${ch == null ? "" : ch >= 0 ? "up" : "down"}">${ch == null ? "…" : pct(ch)}${d != null ? `<br><small style="font-size:12px">${signed(d)}</small>` : ""}</td>
      <td>${tpslBar(p)}</td><td>${ago(p.openedAt)}</td>
      <td><button class="rowbtn danger" type="button" data-sell="${esc(p.mint)}">Sell</button></td></tr>`).join("") ||
      `<tr><td colspan="7" class="empty" style="text-align:center;font-family:var(--body)">No open positions. The bot buys when a coin passes your checks.</td></tr>`;
    $("#pos-m").innerHTML = rows.map(({ p, ch, src }) => `<div class="mcard"><div class="top"><div class="tk">${tokIcon(p)}<div><b>${esc(p.symbol)}</b><small>${esc(src)} · ${ago(p.openedAt)}</small></div></div><b class="mono ${ch == null ? "" : ch >= 0 ? "up" : "down"}">${ch == null ? "…" : pct(ch)}</b></div>${tpslBar(p)}
      <div class="top"><span class="mono muted" style="font-size:12px">${fmtSol(p.cost)} → ${p.value != null ? fmtSol(p.value) : "…"} SOL</span><button class="rowbtn danger" type="button" data-sell="${esc(p.mint)}">Sell</button></div></div>`).join("") || `<p class="empty">No open positions.</p>`;
    $("#open-val").textContent = P.length ? `Unrealized ${signed(unreal)} SOL` : "";
    $("#sell-all").hidden = P.length < 2;
  }
  document.addEventListener("click", (e) => {
    const b = e.target.closest("[data-sell]"); if (!b) return;
    const p = positions[mode].find((x) => x.mint === b.dataset.sell); if (!p) return;
    b.disabled = true; b.textContent = "Selling…"; sell(p, 1, "Manual sell", "sell").finally(() => renderPositions());
  });
  $("#sell-all").addEventListener("click", () => {
    modal("Sell all positions?", `<p>Sells all ${positions[mode].length} open ${mode === "live" ? "live" : "practice"} positions at market.</p><button class="cta" type="button" id="m-sa">Sell all</button>`);
    $("#m-sa").onclick = async () => { closeModal(); for (const p of [...positions[mode]]) await sell(p, 1, "Manual sell", "sell"); };
  });

  const KIND = { tp: "TP", sl: "Stop", buy: "Buy", skip: "Skip", sell: "Sell", err: "Error" };
  function renderFeed() {
    const L = log.filter((x) => !x.m || x.m === mode).slice(0, 40);
    $("#feed").innerHTML = L.map((f) => `<li><span class="kind ${f.k}">${KIND[f.k] || f.k}</span><span class="what">${esc(f.t)}${f.s ? ` <a href="https://solscan.io/tx/${esc(f.s)}" target="_blank" rel="noopener">View</a>` : ""}</span><span class="t">${ago(f.at)}</span></li>`).join("") ||
      `<li style="grid-template-columns:1fr" class="muted">Nothing yet. Start the bot and its buys, sells and skipped rugs show up here.</li>`;
  }
  $("#clear-log").addEventListener("click", () => { log = log.filter((x) => x.m && x.m !== mode); store.set("log", log); renderFeed(); });

  const VL = { pass: "Buy-ready", watch: "Watching", fail: "Blocked", held: "Holding" };
  function renderScan() {
    const st = $("#scan-state");
    if (scanOK === false) { st.classList.add("err"); $("#scan-count").textContent = "Scanner offline: " + scanErr; }
    else if (scanOK) { st.classList.remove("err"); const n = [...scan.values()].filter((x) => verdict(x).v === "pass").length; $("#scan-count").textContent = `${scan.size} new pools · ${n} buy-ready · updated ${ago(lastScan)} ago`; }
    const items = [...scan.values()].map((x) => Object.assign({}, x, verdict(x))).filter((x) => scanFilter === "all" || x.v === scanFilter || (scanFilter === "pass" && x.v === "held"))
      .sort((a, b) => ({ held: 0, pass: 1, watch: 2, fail: 3 }[a.v] - { held: 0, pass: 1, watch: 2, fail: 3 }[b.v]) || b.score - a.score);
    const checks = (t) => `<div class="checks">${Object.keys(CHK).filter((k) => S.f[k]).map((k) => { const v = t.checks ? t.checks[k] : null; return `<span class="chk ${v === true ? "" : v === false ? "bad" : "unk"}">${v === true ? "✓" : v === false ? "✕" : "?"} ${CHK[k].label}</span>`; }).join("")}</div>`;
    const score = (t) => `<div class="score"><span class="m"><i style="width:${t.score}%"></i></span><b>${t.score}</b></div>`;
    const canTrade = mode === "paper" || liveOpen();
    const btn = (t) => t.v === "fail" || t.v === "held" || !canTrade ? `<button class="rowbtn" type="button" disabled>Buy</button>` : `<button class="rowbtn" type="button" data-buy="${esc(t.mint)}">Buy</button>`;
    const name = (t) => `<div class="tk">${tokIcon(t)}<div><b><a href="https://dexscreener.com/solana/${esc(t.pool || t.mint)}" target="_blank" rel="noopener" style="color:inherit;text-decoration:none">${esc(t.symbol)}</a></b><small>${esc(t.name)}${t.dex ? " · " + esc(t.dex.replace(/[-_]/g, " ")) : ""}</small></div></div>`;
    const vd = (t) => `<span class="verdict ${t.v}">${VL[t.v]}</span>${t.why ? `<span class="why">${esc(t.why)}</span>` : ""}`;
    $("#scan-body").innerHTML = items.map((t) => `<tr><td>${name(t)}</td><td>${ago(t.created)}</td><td>$${fmtK(t.liq)}</td><td><span class="up">${t.buys5}</span> / <span class="down">${t.sells5}</span></td><td>${checks(t)}</td><td>${score(t)}</td><td style="max-width:180px">${vd(t)}</td><td>${btn(t)}</td></tr>`).join("") ||
      `<tr><td colspan="8" class="empty" style="text-align:center;font-family:var(--body)">${scanOK === null ? "Loading new pools…" : "Nothing matches this filter right now."}</td></tr>`;
    $("#scan-m").innerHTML = items.map((t) => `<div class="mcard"><div class="top">${name(t)}<div style="text-align:right">${vd(t)}</div></div>${checks(t)}<div class="top"><div class="kv"><div><span>Age</span>${ago(t.created)}</div><div><span>Liquidity</span>$${fmtK(t.liq)}</div><div><span>Score</span>${t.score}</div></div>${btn(t)}</div></div>`).join("") ||
      `<p class="empty">${scanOK === null ? "Loading new pools…" : "Nothing matches this filter right now."}</p>`;
  }
  $$("#scan-verdict button").forEach((b) => b.addEventListener("click", () => { $$("#scan-verdict button").forEach((x) => x.setAttribute("aria-pressed", x === b)); scanFilter = b.dataset.v; renderScan(); }));
  $("#scan-now").addEventListener("click", () => { toast("Refreshing"); runScan(); });
  document.addEventListener("click", (e) => {
    const b = e.target.closest("[data-buy]"); if (!b) return;
    const it = scan.get(b.dataset.buy); if (!it) return;
    if (mode === "live" && !botKp) { toast("Create a bot wallet first"); show("dashboard"); return; }
    b.disabled = true; b.textContent = "Buying…";
    buy(it, "manual").then((ok) => { if (ok) toast(`Bought ${it.symbol}`); renderScan(); });
  });

  function renderCopy() {
    const stats = (f) => { const src = "copy:" + f.addr; const c = closed[mode].filter((x) => x.source === src); return { pnl: c.reduce((a, x) => a + x.pnl, 0), n: c.length + positions[mode].filter((x) => x.source === src).length }; };
    $("#copy-body").innerHTML = follows.map((f, i) => { const s = stats(f); return `<tr><td><div class="tk"><span class="cdot" style="width:30px;height:30px;font-size:11px">${esc((f.name || f.addr).slice(0, 1).toUpperCase())}</span><div><b>${esc(f.name || short(f.addr))}</b><small><a href="https://solscan.io/account/${esc(f.addr)}" target="_blank" rel="noopener">${esc(short(f.addr))}</a>${f.err ? " · " + esc(f.err) : ""}</small></div></div></td>
      <td>${s.n}</td><td class="${s.pnl > 0 ? "up" : s.pnl < 0 ? "down" : ""}">${signed(s.pnl)} SOL</td>
      <td><button class="switch" type="button" role="switch" aria-checked="${!!f.mirror}" data-mirror="${i}" aria-label="Copy sells" style="margin-left:auto;display:block"></button></td>
      <td><button class="rowbtn danger" type="button" data-unfollow="${i}">Stop</button></td></tr>`; }).join("") ||
      `<tr><td colspan="5" class="empty" style="text-align:center;font-family:var(--body)">You're not copying anyone yet. Add a wallet on the right.</td></tr>`;
    $("#copy-m").innerHTML = follows.map((f, i) => { const s = stats(f); return `<div class="mcard"><div class="top"><div class="tk"><span class="cdot" style="width:30px;height:30px;font-size:11px">${esc((f.name || f.addr).slice(0, 1).toUpperCase())}</span><div><b>${esc(f.name || short(f.addr))}</b><small>${esc(short(f.addr))}</small></div></div><button class="rowbtn danger" type="button" data-unfollow="${i}">Stop</button></div>
      <div class="kv"><div><span>Copied buys</span>${s.n}</div><div><span>Your P&amp;L</span><b class="${s.pnl >= 0 ? "up" : "down"}">${signed(s.pnl, 3)}</b></div><div><span>Copy sells</span>${f.mirror ? "On" : "Off"}</div></div></div>`; }).join("") || `<p class="empty">You're not copying anyone yet.</p>`;
    renderEngine();
  }
  document.addEventListener("click", (e) => {
    const u = e.target.closest("[data-unfollow]"), m = e.target.closest("[data-mirror]");
    if (u) { const f = follows.splice(+u.dataset.unfollow, 1)[0]; saveFollows(); renderCopy(); toast("Stopped copying " + (f.name || short(f.addr))); }
    if (m) { const f = follows[+m.dataset.mirror]; f.mirror = !f.mirror; saveFollows(); renderCopy(); }
  });
  $("#add-mirror").addEventListener("click", (e) => { const s = e.currentTarget; s.setAttribute("aria-checked", s.getAttribute("aria-checked") !== "true"); });
  $("#add-form").addEventListener("submit", (e) => {
    e.preventDefault();
    const v = $("#add-addr").value.trim(), er = $("#add-err");
    let ok = isSolAddr(v); if (ok && W) { try { new W.PublicKey(v); } catch (x) { ok = false; } }
    if (!ok) { er.textContent = "That isn't a Solana wallet address. Paste the full address."; er.hidden = false; return; }
    if (follows.some((f) => f.addr === v)) { er.textContent = "You already follow this wallet."; er.hidden = false; return; }
    if (botKp && botKp.publicKey.toBase58() === v) { er.textContent = "That's your own bot wallet."; er.hidden = false; return; }
    er.hidden = true;
    follows.push({ addr: v, name: $("#add-name").value.trim().slice(0, 24), mirror: $("#add-mirror").getAttribute("aria-checked") === "true", last: null, buys: 0, added: Date.now() });
    saveFollows(); $("#add-addr").value = ""; $("#add-name").value = ""; renderCopy(); toast("Following " + short(v));
    if (running) copyTick();
  });

  /* strategy form */
  const num = (id) => +$(id).value;
  function fillForm() {
    $("#s-size").value = S.size; $("#s-max").value = S.maxOpen; $("#s-tp").value = S.tp; $("#s-tpsell").value = S.tpSell; $("#s-sl").value = S.sl; $("#s-trail").value = S.trail; $("#s-hold").value = S.hold;
    $("#s-score").value = S.minScore; $("#s-score-val").textContent = S.minScore; $("#s-liq").value = S.minLiq; $("#s-age").value = S.maxAge;
    $("#s-trail-on").setAttribute("aria-checked", S.trailOn); $("#s-autobuy").setAttribute("aria-checked", S.autoBuy);
    $$("[data-f]").forEach((b) => b.setAttribute("aria-checked", !!S.f[b.dataset.f]));
    $$("#s-slip button").forEach((b) => b.setAttribute("aria-pressed", +b.dataset.v === S.slip));
    $$("#s-prio button").forEach((b) => b.setAttribute("aria-pressed", +b.dataset.v === S.prio));
    renderPlan();
  }
  function renderPlan() {
    const size = Math.max(0, num("#s-size") || 0), tp = Math.max(0, num("#s-tp") || 0), sl = Math.min(95, Math.max(0, num("#s-sl") || 0)), max = Math.max(1, num("#s-max") || 1), f = feeRate("paper");
    const u = (v) => (solUsd ? ` ≈ ${usd(v * solUsd)}` : "");
    $("#p-spend").textContent = `${size} SOL${u(size)}`;
    const ts = Math.min(100, Math.max(1, num("#s-tpsell") || 100)) / 100;
    const win = size * ts * (tp / 100) - size * ts * f * 2, loss = size * (sl / 100) + size * f * 2;
    $("#p-tp").textContent = `+${win.toFixed(4)} SOL`; $("#p-sl").textContent = `−${loss.toFixed(4)} SOL`;
    $("#p-worst").textContent = `−${(loss * max).toFixed(3)} SOL${u(loss * max)}`;
    $("#p-be").textContent = win + loss > 0 ? Math.round((loss / (win + loss)) * 100) + "%" : "—";
    const tpH = Math.min(60, 20 + tp / 5), slH = Math.min(60, 15 + sl / 1.5);
    $("#ladder").innerHTML = `<div class="zone tpz" style="height:${tpH}px"></div><div class="zone slz" style="height:${slH}px"></div>
      <div class="ln" style="top:${tpH}px"></div><span class="lb up" style="top:${tpH}px">TP +${tp}%</span>
      <div class="ln" style="top:50%;border-top-style:solid;border-color:var(--cyan)"></div><span class="lb" style="top:50%;color:var(--cyan)">Entry</span>
      <div class="ln" style="top:calc(100% - ${slH}px)"></div><span class="lb down" style="top:calc(100% - ${slH}px)">SL −${sl}%</span>`;
  }
  ["#s-size", "#s-tp", "#s-tpsell", "#s-sl", "#s-max"].forEach((s) => $(s).addEventListener("input", renderPlan));
  $("#s-score").addEventListener("input", (e) => ($("#s-score-val").textContent = e.target.value));
  $$("#s-slip button, #s-prio button").forEach((b) => b.addEventListener("click", () => [...b.parentElement.children].forEach((x) => x.setAttribute("aria-pressed", x === b))));
  $$("#view-strategy .switch").forEach((sw) => sw.addEventListener("click", () => sw.setAttribute("aria-checked", sw.getAttribute("aria-checked") !== "true")));
  $("#cfg").addEventListener("submit", (e) => {
    e.preventDefault();
    const pressed = (sel, d) => { const b = $(sel + " [aria-pressed='true']"); return b ? +b.dataset.v : d; };
    const n = {
      size: Math.max(0.001, num("#s-size") || DEF.size), maxOpen: Math.min(20, Math.max(1, Math.round(num("#s-max") || DEF.maxOpen))),
      tp: Math.max(5, num("#s-tp") || DEF.tp), tpSell: Math.round(Math.min(100, Math.max(1, num("#s-tpsell") || DEF.tpSell))), sl: Math.min(95, Math.max(1, num("#s-sl") || DEF.sl)), trail: Math.min(80, Math.max(3, num("#s-trail") || DEF.trail)),
      hold: Math.max(5, num("#s-hold") || DEF.hold), minScore: num("#s-score"), minLiq: Math.max(0, num("#s-liq") || 0), maxAge: Math.max(1, num("#s-age") || DEF.maxAge),
      slip: pressed("#s-slip", DEF.slip), prio: pressed("#s-prio", DEF.prio),
      trailOn: $("#s-trail-on").getAttribute("aria-checked") === "true", autoBuy: $("#s-autobuy").getAttribute("aria-checked") === "true", f: {},
    };
    $$("[data-f]").forEach((b) => (n.f[b.dataset.f] = b.getAttribute("aria-checked") === "true"));
    S = n; store.set("settings", S); fillForm(); renderAll(); toast("Strategy saved");
  });

  /* quick settings on the dashboard: save on every change */
  const presetOf = () => Object.keys(PRESETS).find((k) => { const p = PRESETS[k]; return p.minScore === S.minScore && p.minLiq === S.minLiq && p.maxAge === S.maxAge && Object.keys(p.f).every((f) => !!S.f[f] === p.f[f]); }) || null;
  function fillQuick() {
    const act = document.activeElement;
    if (act !== $("#q-size")) $("#q-size").value = S.size;
    if (act !== $("#q-tp")) $("#q-tp").value = S.tp;
    if (act !== $("#q-sl")) $("#q-sl").value = S.sl;
    if (act !== $("#q-tpsell")) $("#q-tpsell").value = S.tpSell;
    $$("#q-tpsell-chips button").forEach((b) => b.setAttribute("aria-pressed", +b.dataset.v === +S.tpSell));
    $("#q-tp-hint").textContent = tpHint();
    $$("#q-size-chips button").forEach((b) => b.setAttribute("aria-pressed", +b.dataset.v === +S.size));
    $$("#q-tp-chips button").forEach((b) => b.setAttribute("aria-pressed", +b.dataset.v === +S.tp));
    const p = presetOf();
    $$("#q-pick button").forEach((b) => b.setAttribute("aria-pressed", b.dataset.p === p));
    $("#q-pick-hint").textContent = p ? PRESET_HINT[p] : "Custom filters from the Strategy tab.";
  }
  function saveQuick(patch, msg) {
    Object.assign(S, patch); store.set("settings", S); fillForm(); renderEngine(); renderPositions(); renderScan();
    clearTimeout(saveQuick._t); saveQuick._t = setTimeout(() => toast(msg || "Saved"), 250);
  }
  const clampNum = (v, lo, hi) => (isFinite(v) && v > 0 ? Math.min(hi, Math.max(lo, v)) : null);
  $("#q-size").addEventListener("change", (e) => { const v = clampNum(+e.target.value, 0.001, 1000); if (v == null) { fillQuick(); return; } saveQuick({ size: v }, `Buy size: ${v} SOL`); });
  $("#q-tp").addEventListener("change", (e) => { const v = clampNum(+e.target.value, 5, 10000); if (v == null) { fillQuick(); return; } saveQuick({ tp: v }, `Take-profit: +${v}%`); });
  $("#q-sl").addEventListener("change", (e) => { const v = clampNum(+e.target.value, 1, 95); if (v == null) { fillQuick(); return; } saveQuick({ sl: v }, `Stop-loss: −${v}%`); });
  function tpHint() { const r = 100 - S.tpSell; return S.tpSell >= 100 ? `At +${S.tp}%, sell the whole position.` : `At +${S.tp}%, sell ${S.tpSell}% and keep ${r}%${S.trailOn ? `, which rides until it drops ${S.trail}% from its peak` : " until stop-loss or max hold time"}.`; }
  $("#q-tpsell").addEventListener("change", (e) => { const v = clampNum(+e.target.value, 1, 100); if (v == null) { fillQuick(); return; } saveQuick({ tpSell: Math.round(v) }, `Sell ${Math.round(v)}% at take-profit`); });
  $$("#q-tpsell-chips button").forEach((b) => b.addEventListener("click", () => saveQuick({ tpSell: +b.dataset.v }, `Sell ${b.dataset.v}% at take-profit`)));
  $$("#q-size-chips button").forEach((b) => b.addEventListener("click", () => saveQuick({ size: +b.dataset.v }, `Buy size: ${b.dataset.v} SOL`)));
  $$("#q-tp-chips button").forEach((b) => b.addEventListener("click", () => saveQuick({ tp: +b.dataset.v }, `Take-profit: +${b.dataset.v}%`)));
  $$("#q-pick button").forEach((b) => b.addEventListener("click", () => { const p = PRESETS[b.dataset.p]; saveQuick({ minScore: p.minScore, minLiq: p.minLiq, maxAge: p.maxAge, f: Object.assign({}, p.f) }, b.textContent); }));
  $("#qs").addEventListener("submit", (e) => { e.preventDefault(); document.activeElement && document.activeElement.blur(); });

  /* views */
  function show(v) {
    $$(".view").forEach((el) => (el.hidden = el.id !== "view-" + v));
    $$("[data-view]").forEach((b) => b.setAttribute("aria-selected", b.dataset.view === v));
    store.set("view", v); window.scrollTo({ top: 0 });
  }
  $$("[data-view]").forEach((b) => b.addEventListener("click", () => show(b.dataset.view)));
  $("#brand").addEventListener("click", (e) => { e.preventDefault(); show("dashboard"); });
  $("#wallet-btn").addEventListener("click", openConnect);
  $("#chain-btn").addEventListener("click", () => modal("Chains", `<button class="witem" type="button" data-close><span class="cdot" style="width:34px;height:34px;font-size:13px">S</span><span><b>Solana</b><small>Jupiter swaps · live Oct 3</small></span><span class="st" style="color:var(--up)">Active</span></button>
    <button class="witem" type="button" disabled style="opacity:.6;cursor:default"><span class="cdot" style="width:34px;height:34px;font-size:13px;background:#ccff00">R</span><span><b>Robinhood Chain</b><small>Uniswap V3</small></span><span class="st">Coming soon</span></button>`));

  function renderAll() { renderHeader(); renderStatus(); renderEngine(); renderWallet(); renderStats(); renderPositions(); renderFeed(); renderScan(); renderCopy(); }

  /* ---------- boot ---------- */
  fillForm(); renderAll();
  const hv = location.hash.replace("#", "").split(/[-_]/)[0];
  const startView = hv === "copy" ? "strategy" : ["dashboard", "scanner", "strategy"].includes(hv) ? hv : store.get("view", "dashboard");
  show(startView === "copy" ? "strategy" : startView);
  if (hv === "copy") setTimeout(() => $("#copy-sec").scrollIntoView(), 50);
  if (conn) {
    runScan(); refreshSolUsd(); refreshBotBal(); checkHolder();
    setInterval(runScan, 30000);
    setInterval(() => { if (positions.paper.length || positions.live.length) monitor(); }, 12000);
    setInterval(copyTick, 25000);
    setInterval(refreshBotBal, 20000);
    setInterval(refreshSolUsd, 60000);
  }
  setInterval(() => { renderStatus(); renderFeed(); if (scanOK) renderScan(); }, 30000);
  window.addEventListener("beforeunload", (e) => { if (running || positions.live.length) { e.preventDefault(); e.returnValue = ""; } });
  document.addEventListener("visibilitychange", async () => { if (!document.hidden && running && navigator.wakeLock && !wakeLock) { try { wakeLock = await navigator.wakeLock.request("screen"); } catch (e) {} } });
})();
